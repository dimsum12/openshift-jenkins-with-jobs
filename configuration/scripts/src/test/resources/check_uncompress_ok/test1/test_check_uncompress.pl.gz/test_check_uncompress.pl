#!/usr/bin/perl

BEGIN {
	push @INC, "/home/debian/workspace/gpp3/entrepot_scripts/src/main/scripts/fr/geoportail/entrepot/scripts/verification";
}


use Test::Simple;
use Config::Simple;

require "check_uncompress.pl";


my $config_path = "/home/debian/workspace/gpp3/entrepot_scripts/src/test/config/local";

$config = new Config::Simple($config_path."/config_perl.ini") or die Config::Simple->error();
my $resources_path = $config->param("resources.path");

ok( check_uncompress($resources_path."check_uncompress_ok") == 0, "Test avec des archives valides" );
ok( check_uncompress($resources_path."check_uncompress_bad_type") == -1, "Test avec un type inconnu" );
ok( check_uncompress($resources_path."check_uncompress_nok") == -2, "Test avec une erreur de d�compression" );
ok( check_uncompress("/rep/not/exist") == -3, "Test avec un r�pertoire qui n'existe pas");
ok( check_uncompress() == -5, "Test sans param�tre" );

